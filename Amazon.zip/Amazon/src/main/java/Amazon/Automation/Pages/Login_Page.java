package Amazon.Automation.Pages;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.LogStatus;

import Amazon.Automation.Library.GenericFunctions;

public class Login_Page extends Amazon.Automation.Library.GenericFunctions {
	
	public void Login(int rownum) throws IOException, InvalidFormatException, InterruptedException {
		 xl_GetData(rownum);	
		 String UserName=TestDataHM.get("UserName");
		 String TestName=gm_TestCaseName("Test_Case_Name");
		 String Password=TestDataHM.get("Password");
 		 gm_WaitVIsibility("username", 8000);
		 gm_Input("username", UserName);
		 ClickOnWebElement("continue");
		 gm_Input("password", Password);
         gm_Click("loginbutton");
       	 
	}   
	
	public void FMP2Login(int rownum) throws IOException, InvalidFormatException, InterruptedException {
		 xl_GetData(rownum);	
		 String UserName=TestDataHM.get("FMP2UserName");
		 String TestName=gm_TestCaseName("Test_Case_Name");
		 String Password=TestDataHM.get("FMP2Password");
		 gm_WaitVIsibility("fmp2username", 8000);
		 gm_Input("fmp2username", UserName);
		 gm_Input("fmp2password", Password);
        gm_Click("fmp2signinbutton");
      	 gm_WaitVIsibility("fmp2logout", 20000);
      	 
	}
	
	public void IFMLogin(int rownum) throws IOException, InvalidFormatException, InterruptedException {
		 xl_GetData(rownum);	
		 String UserName=TestDataHM.get("FMP2UserName");
		 String TestName=gm_TestCaseName("Test_Case_Name");
		 String Password=TestDataHM.get("FMP2Password");
		 gm_WaitVIsibility("fmp2username", 8000);
		 gm_Input("fmp2username", UserName);
		 gm_Input("fmp2password", Password);
         gm_Click("fmp2signinbutton");
         Thread.sleep(5000);
         driver.navigate().to("https://staging.fmpilot2.com/Client/ClientMain.aspx?ID=66");
     	 gm_WaitVIsibility("fmp2logout", 20000);
     	 
	}
}
