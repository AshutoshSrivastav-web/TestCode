package Amazon.Automation.Library;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.*;
import java.net.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;



import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.*;
import org.openqa.selenium.html5.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.TouchAction;
import org.openqa.selenium.logging.*;
import org.openqa.selenium.remote.*;
import org.openqa.selenium.Cookie.Builder;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;
//import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.google.common.base.VerifyException;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Amazon.Automation.Pages.Login_Page;

import org.apache.commons.*;

	public class GenericFunctions{

		public static ExtentReports extent;
		public static ExtentTest test;
		public static HashMap<String, String> TestDataHM;
		public static final boolean ENABLE_TEST = true;
		@SuppressWarnings("rawtypes")
		protected static WebDriver driver;
		//protected static AndroidDriver driver;
	    public static String url,BrowserType;
		public static Properties prop;
	    public static String FileName=System.getProperty("user.dir") + "/datafile.properties";
	    public static String DownloadedFolder= System.getProperty("user.home") + "\\Downloads\\";
	    public static ArrayList<String> tabs;
		
	   

	    //public String ObjectName="C:/Users/nt7087/workspace/App/ObjectRepository.properties";
	 	//Variable for Hashmap
    	//public static HashMap<String, String> TestDataHM;
    	
	    
	  //Variable for log4j file
	  	public static final String ConfigFilePath="log4j.properties";
	  	
	  	
	  	public static DesiredCapabilities capabilities;
	  	public static String ServiceProvider;
	  		
	  	//Variable for log4j config object
	  	public static Properties ConfigObject;
	  		
	  	//Variable for incrementing values for screenshots
	  	static public int imageNameCounter=0;
    	//Variable for TestDataPath
    public static String TestDataPath=System.getProperty("user.dir") + "/Testcases.xlsx";

    //Variable for SheetName
    public static String SheetName="Sheet1";

    //Array List for Result sheet column name
    public static final String[] ArrColumnName={"ModuleName", "SubModuleName","TestCaseID",
        "FieldName","ExpectedResult","Actualresult",
        "Status", "Snapshot"};

    //Variable for Results FilePath
    public static String FilePath="";

    //Variable for Results FolderPath
    public static String FolderPath="Results/";


    //Variable for Results ResultSheet
    public static String ResSheetName="ResultSheet";

	    /*
	     * Creates the Appium driver to run the test on.
	     *
	     * To use:
	     * For Appium server, save the apiDemos.apk application locally.
	     */    
	   
    static {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("yyyy.MM.dd_HH.mm.ss");
		extent = new ExtentReports(System.getProperty("user.dir") + "/src/main/java/report/AutomationExecutionReport" + formater.format(calendar.getTime()) + ".html", false); 
	}
	
	public void getresult(ITestResult result) {
		if (result.getStatus()== ITestResult.SUCCESS) {
			test.log(LogStatus.PASS, result.getName() + " Test is Pass");
		}else if (result.getStatus()==ITestResult.SKIP) {
			test.log(LogStatus.SKIP, result.getName() + "Test is Skipped and Skip Reason is:-" + result.getThrowable());
		}else if (result.getStatus()==ITestResult.FAILURE) {
			test.log(LogStatus.FAIL, result.getName() + "Test is Failed due to:-" + result.getThrowable());
		}else if (result.getStatus()==ITestResult.STARTED) {
			test.log(LogStatus.INFO, result.getName() + "Test is Started");
		}
	}
	   //Function to wait until to check visiblity 
		public static void gm_WaitVIsibility(String PropName, int timeOut_Sec) throws InvalidFormatException, IOException, InterruptedException{
			String PropValue=prop.getProperty(PropName);
			WebElement we=CreateWebElement(PropValue);
			WebDriverWait wtObj=new WebDriverWait(driver, timeOut_Sec);	
			wtObj.until(ExpectedConditions.visibilityOf(we));
			 test.log(LogStatus.PASS, PropName+" Visible Successfully");

			
		}
		
		
		public static String GetCurrentDate() {
			
			Date date = new Date(System.currentTimeMillis());
		    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		    String s = formatter.format(date);
		    return s;
		}
		
		public static void MouseHover(String PropName) throws InvalidFormatException, IOException, InterruptedException {
			String PropValue=prop.getProperty(PropName);
			WebElement we=CreateWebElement(PropValue);
            Actions act=new Actions(driver);
			act.moveToElement(we).build().perform();
		}
		
		//Function to wait until to check enable 
		public static void gm_WaitEnabled(String PropName, int timeOut_Sec) throws InvalidFormatException, IOException, InterruptedException{
			String PropValue=prop.getProperty(PropName);
			WebElement we=CreateWebElement(PropValue);
			WebDriverWait wtObj=new WebDriverWait(driver, timeOut_Sec);	
			wtObj.until(ExpectedConditions.elementToBeClickable(we));
			test.log(LogStatus.PASS, PropName+" Enabled Successfully");

		}
		
		
  //Function to Launch Browser
		
	public static void LaunchBrowser(String BrowserType) throws IOException, InvalidFormatException, InterruptedException {
		File file = new File(FileName);
	       // File file1 = new File(ObjectName);
	  	  
			FileInputStream fileInput = null;
			//FileInputStream fileInput1 = null;
			try {
				fileInput = new FileInputStream(file);
				//fileInput1 = new FileInputStream(file1);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			prop = new Properties();
			
			//load properties file
			try {
				prop.load(fileInput);
				//prop.load(fileInput1);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			test.log(LogStatus.PASS, "Properties Files Loaded Successfully");
			//capabilities.setCapability("no",true);
		
		if(BrowserType.equalsIgnoreCase("Chrome")) {
			System.setProperty("Webdriver.chrome.driver", System.getProperty("user.dir") + "chromedriver.exe");
			driver=new ChromeDriver();
			 gm_WriteToLog("Chrome Browser Launched Successfully","I");
			 test.log(LogStatus.PASS, "Chrome Browser Launched Successfully");

		}
		if(BrowserType.equalsIgnoreCase("Edge")) {
			driver=new EdgeDriver();
			 gm_WriteToLog("MicrosoftEdge Browser Launched Successfully","I");
			 test.log(LogStatus.PASS, "MicrosoftEdge Browser Launched Successfully");
		}
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		driver.manage().window().maximize();

	}
	
	//Function to Open URL
	
		public static Login_Page OpenURL(String BrowserType,String URL) throws IOException, InvalidFormatException, InterruptedException {
			LaunchBrowser(BrowserType);
			driver.get(URL);
			gm_WriteToLog("URL: "+URL+" Opened Successfully","I");
			test.log(LogStatus.PASS, "URL: "+URL+" Opened Successfully");
			Login_Page lpg=PageFactory.initElements(driver, Login_Page.class);
			return lpg;
	
		}
			
  //Function to perform click operation
    
    public static void gm_Click(String PropName) throws IOException, InvalidFormatException, InterruptedException{
    	String PropValue=prop.getProperty(PropName);
		WebElement we=CreateWebElement(PropValue);
	   	boolean st=gm_checkVisibility(we);
	   	if(!PropName.equalsIgnoreCase("equipmentdropdownvalue")) {
	   		gm_WaitVIsibility(PropName,8000);
			gm_WaitEnabled(PropName,8000);
				}
		if(st==true){
		 gm_WriteToLog("WebElement: " +we+ " is Visible On Application","I");
			Assert.assertEquals(true,true);
			boolean enable=gm_checkEnabled(we);
			   if(enable==true){
			    gm_WriteToLog("WebElement " +we+ " is Enabled On Application","I");
				   Assert.assertEquals(true,true);
				   Thread.sleep(500);
				   we.click();
				   test.log(LogStatus.PASS, PropName+" Clicked Successfully");
				   gm_WriteToLog( PropName+" Clicked Successfully","I");
				   if(PropName.equalsIgnoreCase("fmp2searchworkorderbutton")) {
					   if(isAlertPresent()){
			  		        Alert alert = driver.switchTo().alert();
			  		        System.out.println(alert.getText());
			  		        alert.accept();
	                        test.log(LogStatus.FAIL, "WorkOrder Not Exists");
	                        driver.quit();

			  		    }
				   }
					if(PropName.equalsIgnoreCase("equipmentdropdown")) {
						   Thread.sleep(2000);
				    	String PropValue1=prop.getProperty("equipmentdropdownvalue");
						   we.click();
						WebElement we1=CreateWebElement(PropValue1);
                           we1.click();
                        test.log(LogStatus.PASS, "equipmentdropdownvalue"+" Clicked Successfully");
     				    gm_WriteToLog( "equipmentdropdownvalue"+" Clicked Successfully","I");
     			
							}
					
     	  			if(PropName.equalsIgnoreCase("delete")||PropName.equalsIgnoreCase("quotedelete"))
		  			 {
		  			    Alert alert = driver.switchTo().alert();
		  			    alert.accept();
						test.log(LogStatus.PASS, "Alert Closed Successfully");
			  			Thread.sleep(10000);

		  			 }
     	  			if(PropName.equalsIgnoreCase("emailcommentsearchusersubmit1"))
		  			 {
     	  				
     	  			 VerifyAlertText();
		  			 }
     	  			
     	  			if(PropName.equalsIgnoreCase("emailcommentsubmit1"))
		  			 {
     	  				
    	  				
    	  			 VerifyAlertText();
		  			 }
     	  		  if(PropName.equalsIgnoreCase("fmp2addcommentinnerbutton")) {
                   test.log(LogStatus.PASS, "fmp2addcommentinnerbutton"+" Clicked Successfully");
				    gm_WriteToLog( "fmp2addcommentinnerbutton"+" Clicked Successfully","I");
 
     	  			  String TS=fn_GetTimeStamp();
		               String TestName=gm_TestCaseName("Test_Case_Name");
		    		 
				}

     	  			
     	  			
     	  		   if(!PropName.equalsIgnoreCase("equipmentdropdown") && !PropName.equalsIgnoreCase("fmp2addcommentinnerbutton")) {
					   String TS=fn_GetTimeStamp();
		               String TestName=gm_TestCaseName("Test_Case_Name");
		    		   String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
		  			   SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);

				}
	  			  
				   
			   }
			   else{
				   
			    gm_WriteToLog("WebElement " +we+ " is Not Enabled On Application","E");
				 String TS=fn_GetTimeStamp();
	            	String TestName=gm_TestCaseName("Test_Case_Name");
	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			String str="WebElement " +we+ " is Not Enabled On Application";
	  			String Value="WebElement " +we+ " is  Enabled On Application";
	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str, "Failed", SnapshotPath, 3);
	  				xl_WriteResult(ArrSteps);
	  				 Reporter.log("WebElement " +we+ " is Not Enabled On Application");
				 Assert.fail("WebElement " +we+ " is Not Found");
				 test.log(LogStatus.FAIL,  PropName+" Not Clicked Successfully");

			   }
	       		
		}else{
		 gm_WriteToLog("WebElement " +we+ " is Not Displayed On Application","E");
		 String TS=fn_GetTimeStamp();
     	String TestName=gm_TestCaseName("Test_Case_Name");
			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
			SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		String str="WebElement " +we+ " is Not Displayed On Application";
		String Value="WebElement " +we+ " is  Displayed On Application";
		String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str, "Failed", SnapshotPath, 3);
		 Reporter.log("WebElement " +we+ " is Not Displayed On Application");
		 Assert.fail("WebElement " +we+ " is Not Displayed");
		}
	
		
	}
	
    
    public static void gm_ClickandClearContents(String PropName) throws IOException, InvalidFormatException, InterruptedException{
    	String PropValue=prop.getProperty(PropName);
		WebElement we=CreateWebElement(PropValue);
	   	boolean st=gm_checkVisibility(we);
		gm_WaitVIsibility(PropName,8000);
		gm_WaitEnabled(PropName,8000);
		if(st==true){
		 gm_WriteToLog("WebElement: " +we+ " is Visible On Application","I");
			Assert.assertEquals(true,true);
			boolean enable=gm_checkEnabled(we);
			   if(enable==true){
			    gm_WriteToLog("WebElement " +we+ " is Enabled On Application","I");
				   Assert.assertEquals(true,true);
				   Thread.sleep(500);
				   we.click(); 
				   we.sendKeys(Keys.CONTROL + "a");
				   Thread.sleep(1000);
				   we.sendKeys(Keys.DELETE);
				  Thread.sleep(1000);
				   test.log(LogStatus.PASS, PropName+" Clicked Successfully");
				   gm_WriteToLog( PropName+" Clicked Successfully","I");
				   String TS=fn_GetTimeStamp();
	               String TestName=gm_TestCaseName("Test_Case_Name");
	    		   String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
     	  			if(PropName.equalsIgnoreCase("delete"))
		  			 {
		  			    Alert alert = driver.switchTo().alert();
		  			    alert.accept();
						test.log(LogStatus.PASS, "Alert Closed Successfully");
			  			Thread.sleep(10000);

		  			 }
     	  			if(PropName.equalsIgnoreCase("emailcommentsearchusersubmit1"))
		  			 {
     	  				
     	  			 VerifyAlertText();
		  			 }
     	  			
		  			
		  			
	  			   SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  
				   
			   }
			   else{
				   
			    gm_WriteToLog("WebElement " +we+ " is Not Enabled On Application","E");
				 String TS=fn_GetTimeStamp();
	            	String TestName=gm_TestCaseName("Test_Case_Name");
	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			String str="WebElement " +we+ " is Not Enabled On Application";
	  			String Value="WebElement " +we+ " is  Enabled On Application";
	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str, "Failed", SnapshotPath, 3);
	  				xl_WriteResult(ArrSteps);
	  				 Reporter.log("WebElement " +we+ " is Not Enabled On Application");
				 Assert.fail("WebElement " +we+ " is Not Found");
				 test.log(LogStatus.FAIL,  PropName+" Not Clicked Successfully");

			   }
	       		
		}else{
		 gm_WriteToLog("WebElement " +we+ " is Not Displayed On Application","E");
		 String TS=fn_GetTimeStamp();
     	String TestName=gm_TestCaseName("Test_Case_Name");
			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
			SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		String str="WebElement " +we+ " is Not Displayed On Application";
		String Value="WebElement " +we+ " is  Displayed On Application";
		String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str, "Failed", SnapshotPath, 3);
		 Reporter.log("WebElement " +we+ " is Not Displayed On Application");
		 Assert.fail("WebElement " +we+ " is Not Displayed");
		}
	
		
	}
    
    public static void gm_Input(String PropName,String Value1) throws IOException, InvalidFormatException, InterruptedException{
    	String PropValue=prop.getProperty(PropName);
		WebElement we=CreateWebElement(PropValue);
	   	boolean st=gm_checkVisibility(we);
		gm_WaitVIsibility(PropName,8000);
		gm_WaitEnabled(PropName,8000);
		if(st==true){
		 gm_WriteToLog("WebElement: " +we+ " is Visible On Application","I");
			Assert.assertEquals(true,true);
			boolean enable=gm_checkEnabled(we);
			   if(enable==true){
			    gm_WriteToLog("WebElement " +we+ " is Enabled On Application","I");
				   Assert.assertEquals(true,true);
				   we.click();  
				   we.clear();
				   we.sendKeys(Value1);
				   test.log(LogStatus.PASS,  "Value: "+Value1+ " For "+ PropName+" Entered Successfully");
				   gm_WriteToLog( "Value: "+Value1+ " For "+ PropName+" Entered Successfully","I");
				   String TS=fn_GetTimeStamp();
	               String TestName=gm_TestCaseName("Test_Case_Name");
	    		   String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
	  			   SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);

				   
			   }else{
				   
			    gm_WriteToLog("WebElement " +we+ " is Not Enabled On Application","E");
				 String TS=fn_GetTimeStamp();
	            	String TestName=gm_TestCaseName("Test_Case_Name");
	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			String str="WebElement " +we+ " is Not Enabled On Application";
	  			String Value="WebElement " +we+ " is  Enabled On Application";
	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str, "Failed", SnapshotPath, 3);
	  				xl_WriteResult(ArrSteps);
	  				 Reporter.log("WebElement " +we+ " is Not Enabled On Application");
				 Assert.fail("WebElement " +we+ " is Not Found");
				 test.log(LogStatus.FAIL,  "Value: "+Value1+ " For "+ PropName+" Not Entered Successfully");

			   }
	       		
		}else{
		 gm_WriteToLog("WebElement " +we+ " is Not Displayed On Application","E");
		 String TS=fn_GetTimeStamp();
     	String TestName=gm_TestCaseName("Test_Case_Name");
			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +TestName ;
			SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		String str="WebElement " +we+ " is Not Displayed On Application";
		String Value="WebElement " +we+ " is  Displayed On Application";
		String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str, "Failed", SnapshotPath, 3);
		 Reporter.log("WebElement " +we+ " is Not Displayed On Application");
		 Assert.fail("WebElement " +we+ " is Not Displayed");
		}
	
		
	}
   	public  void xl_GetData( int rowNum) throws IOException{
   		xl_GetData(TestDataPath,SheetName, rowNum);
   	   
   	}
   	
   	//Function to get data from input sheet
   	@SuppressWarnings("deprecation")
		public static void xl_GetData(String xlFilePath,String SheetName, int rowNum) throws IOException{

   			Workbook wBookObject=xl_GetTDWorkBook(xlFilePath);
   			Sheet sheetObj=wBookObject.getSheet(SheetName);
   			int rowCnt=sheetObj.getLastRowNum();
   			MissingCellPolicy mcp=Row.MissingCellPolicy.CREATE_NULL_AS_BLANK;
   			Row fstRowObj=sheetObj.getRow(0);
   			int columnCnt=fstRowObj.getLastCellNum();
   				Row rowObj=sheetObj.getRow(rowNum);
   				HashMap<String, String> HMObj=new HashMap<String, String>();
   				
   				
   				String Data="";
   				for(int j=0; j<=columnCnt-1;j++){
   					String ColumnName=fstRowObj.getCell(j).getStringCellValue();
   					Cell cellObj=rowObj.getCell(j, mcp);
   					int cellTypeNum=cellObj.getCellType();
   					if(cellTypeNum==Cell.CELL_TYPE_NUMERIC){
   						Double dblData=cellObj.getNumericCellValue();	
   						Integer intData=dblData.intValue();
   						Data=intData.toString();
   					}else if(cellTypeNum==Cell.CELL_TYPE_STRING){
   						   Data=cellObj.getStringCellValue();
   						
   					}
   					else if(cellTypeNum==Cell.CELL_TYPE_BLANK){
						   Data="";
						
					}
   					HMObj.put(ColumnName, Data);
   					
   				}
   				TestDataHM=HMObj;
   			
   	}
   	
   	
   	//Function to select worksheet for user input data
   	public static Workbook xl_GetTDWorkBook(String FilePath) throws IOException{
   		FileInputStream fisObj=new FileInputStream(FilePath);
   		String[] pathArr=FilePath.split("\\.");
   		String ext=pathArr[1];
   		Workbook wBookObj=null;
   		if(ext.equalsIgnoreCase("xls")){
   			wBookObj=new HSSFWorkbook(fisObj);
   		}else if(ext.equalsIgnoreCase("xlsx")){
   			wBookObj=new XSSFWorkbook(fisObj);
   		}
   		return wBookObj;
   	}
   	
   	//Function to write results on result sheet
   	public static void xl_WriteResult(String[] ArrSteps) throws IOException, InvalidFormatException{
   		File fileObj=new File(FilePath);
   		if(fileObj.exists()==false){
   			xl_CreateResultSheet();
   		}
   		xl_UpdateResultSheet(ArrSteps);
   		
   	}
   	

   	
   	
   	//Function to update result sheet
   	public static void xl_UpdateResultSheet(String[] ArrSteps) throws IOException, InvalidFormatException{
   		FileInputStream FIS=new FileInputStream(FilePath);
   		Workbook wbookObj=WorkbookFactory.create(FIS);
   		Sheet sheetObj=wbookObj.getSheet(ResSheetName);
   		int rownum=sheetObj.getLastRowNum();
   		rownum=rownum+1;
   		boolean status=false;
   		if(ArrSteps[6].equalsIgnoreCase("Passed")){
   			status=true;		
   		}
   		Row rowObj=sheetObj.createRow(rownum);
   		for(int i=0; i<=ArrSteps.length-1;i++){
   			Cell cellObj=rowObj.createCell(i);
   			if(status==false){
   				short redcolorno=IndexedColors.RED.getIndex();
   				CellStyle failStyle=fn_CreateCellStyle(wbookObj,redcolorno);
   				cellObj.setCellStyle(failStyle);
   				
   				if(i==ArrSteps.length-1){
   			
   					String snapPath=ArrSteps[i];
   					snapPath=snapPath.replaceAll("Results/", "");
   					//snapPath=snapPath.replaceAll("/", "\\");
   					CellStyle st=fn_LinkFontStyle(wbookObj, failStyle);
   					cellObj.setCellStyle(st);
   					String LinkFormla="HYPERLINK("+'"'+snapPath+'"'+", "+'"'+"snapshot"+'"'+")";
   					cellObj.setCellFormula(LinkFormla);
   					
   				}else{
   					cellObj.setCellValue(ArrSteps[i]);
   				}
   			}
   			if(status==true){
   				short redcolorno=IndexedColors.GREEN.getIndex();
   				CellStyle failStyle=fn_CreateCellStyle(wbookObj,redcolorno);
   				cellObj.setCellStyle(failStyle);
   				
   				if(i==ArrSteps.length-1){
   			
   					String snapPath=ArrSteps[i];
   					snapPath=snapPath.replaceAll("Results/", "");
   					//snapPath=snapPath.replaceAll("/", "\\");
   					CellStyle st=fn_LinkFontStyle(wbookObj, failStyle);
   					cellObj.setCellStyle(st);
   					String LinkFormla="HYPERLINK("+'"'+snapPath+'"'+", "+'"'+"snapshot"+'"'+")";
   					cellObj.setCellFormula(LinkFormla);
   					
   				}else{
   					cellObj.setCellValue(ArrSteps[i]);
   				}
   			}
   			else{
   				cellObj.setCellValue(ArrSteps[i]);
   			}
   			
   				
   		}
   		FileOutputStream fos=new FileOutputStream(FilePath);
   		wbookObj.write(fos);
   	}
   	
   	//Function to create result sheet
   	public static void xl_CreateResultSheet() throws IOException{
   		Workbook wBookObj=xl_GetWorkBook("xlsx");
   		Sheet sheetObj=wBookObj.createSheet(ResSheetName);
   		Row rowObj=sheetObj.createRow(0);
   		/////////////////////////////////
   		CellStyle styleObject=fn_CreateCellStyle(wBookObj, IndexedColors.YELLOW.getIndex());
   		  fn_CreateFontStyle(wBookObj, styleObject, 13);
   		for(int i=0; i<=ArrColumnName.length-1;i++){
   			Cell cellObj=rowObj.createCell(i);
   			cellObj.setCellValue(ArrColumnName[i]);
   			cellObj.setCellStyle(styleObject);
   			//sheetObj.autoSizeColumn(i);
   		}
   		String TS=fn_GetTimeStamp();
   		FilePath=FolderPath+"Result_"+TS+".xlsx";
   		FileOutputStream fos=new FileOutputStream(FilePath);
   		wBookObj.write(fos);
   		wBookObj.close();
   	}
   	
   	
   	
   	//Function to create cell styles on worksheet  of selected workbook
   	public static  CellStyle fn_CreateCellStyle(Workbook wBookObj, short ColorNo){
   		CellStyle styleObj=wBookObj.createCellStyle();
   		
   		styleObj.setFillForegroundColor( ColorNo);
   		styleObj.setFillPattern(FillPatternType.SOLID_FOREGROUND);
   		return styleObj;
   	}
   	
   	//Function to set font styles of cells on worksheet  of selected workbook
   	public static CellStyle fn_CreateFontStyle(Workbook wBookObj, CellStyle styleObj,int height){
   		  Font fontObj=wBookObj.createFont();
   		  fontObj.setFontHeightInPoints((short) height);
   		  fontObj.setBold(true);
   		  styleObj.setFont(fontObj);
   		  return styleObj;
   	}
   	
   	//Function to set cell styles on worksheet  of selected workbook
   	public static  CellStyle fn_LinkFontStyle(Workbook wBookObj, CellStyle styleObj){
   		  Font fontObj=wBookObj.createFont();
   		  fontObj.setColor(IndexedColors.BLUE.getIndex());
   		  
   		  fontObj.setUnderline(Font.U_SINGLE);
   		  styleObj.setFont(fontObj);
   		  return styleObj;
   	}
   	
   	//Function to select workbook
   	public static  Workbook xl_GetWorkBook(String ext) throws IOException{
   		Workbook wBookObj=null;
   		if(ext.equalsIgnoreCase("xls")){
   			wBookObj=new HSSFWorkbook();
   		}else if(ext.equalsIgnoreCase("xlsx")){
   			wBookObj=new XSSFWorkbook();
   		}
   		return wBookObj;
   	} 
   	
 public static WebElement WriteWebElement(String we){
		
		String we1=prop.getProperty(we);
		WebElement we11=driver.findElement(By.xpath(we1));
		return we11;
	}
 
	

    
	//Function to custom wait until to check display of webelement 
	public static boolean gm_CustomWait(WebElement we, int timeOut) {
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		boolean st=false;
		for(int i=1;i<=timeOut;i++){
			try{
				we.isDisplayed();
				st=true;
				break;
			}catch(NoSuchElementException ne){
			
						try {
							Thread.sleep(300);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			}
		}
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		return st;
		
	}
   	
    
   
	
   
    public static String getpropvalue(String PropName) {
    	String propvalue=prop.getProperty(PropName);
    	return propvalue;
    }
    
    
   

   
	    
	  //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtext(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			String Expected=TestDataHM.get("Expected");
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  				if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Value Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
	  	  				counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found Successfully");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	            	

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  		
	  	//Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtext1(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			String Expected=TestDataHM.get("Expected");
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName+"//input"));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  				if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Value Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
	  	  				counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found Successfully");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	            	

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  		
	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtextWithAttribute(String PropName,String Attribute) throws InterruptedException, IOException, InvalidFormatException{
	  			String Expected=TestDataHM.get("Expected");
	  			     String str;
	  			     int counter=0;
		  			 List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getAttribute(Attribute).trim();
	  			if(str.trim().contains((Expected.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Value Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
	  	  				counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found Successfully");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	            	

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  		
	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtextAttributeValueFromProp(String PropName,String Attribute,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			String propvalue=prop.getProperty(PropName);
	  			propvalue=propvalue.split(";")[1].toString().trim();
	  			     String str;
	  			     int counter=0;
		  			 List<WebElement> lst=driver.findElements(By.xpath(propvalue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getAttribute(Attribute).trim();
	  			  			     System.out.println(str);

	  			if(str.trim().contains((Expected.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Value Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
	  	  				counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found Successfully");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	            	

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}

	  	
	  		
	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtextWithAttributeAndValue(String PropName,String Attribute,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			//String Expected=TestDataHM.get("Expected");
	  			     String str;
	  			     int counter=0;
		  			 List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getAttribute(Attribute).trim();
	  			    			  System.out.println(str);
	  			if(str.trim().contains((Expected.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Value Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
	  	  				counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found Successfully");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	            	

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}

	  		
	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtextFromPassedValues(String PropName,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  			    			  System.out.println(str);
	  				if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  		
	  		
	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtextFromPropNamePassedValues(String PropName,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			     String str;
	  			     int counter=0;
	  		    	String propvalue=prop.getProperty(PropName);
		  			propvalue=propvalue.split(";")[1].toString().trim();
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  			    			  System.out.println(str);
	  				if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}

	  		
	  		
	  		public static void SelectFileUsingRobot() throws AWTException, InterruptedException {
	  			
	  			String UploadFileName=System.getProperty("user.dir") + "\\"+TestDataHM.get("FileName");

	  			StringSelection stringSelection = new StringSelection(UploadFileName);
	  			 Toolkit tol = Toolkit.getDefaultToolkit();

	  		    // get control of mouse cursor

	  		    Clipboard c = tol.getSystemClipboard();

	  		    // copy the path into mouse
	  		    c.setContents(stringSelection, null);

	  		    // create a object of robot class

	  		    Robot r = new Robot();

	  		    r.keyPress(KeyEvent.VK_CONTROL);
	  		    r.keyPress(KeyEvent.VK_V);
	  		    r.keyRelease(KeyEvent.VK_CONTROL);
	  		    r.keyRelease(KeyEvent.VK_V);
	  		    r.keyPress(KeyEvent.VK_ENTER);
	  		    r.keyRelease(KeyEvent.VK_ENTER);
	  		    Thread.sleep(10000);
	  		}
	  		
             public static void ClickRobotEnter() throws AWTException, InterruptedException {
	  			
	  		    // create a object of robot class

	  		    Robot r = new Robot();

	  		    r.keyPress(KeyEvent.VK_ENTER);
	  		    r.keyRelease(KeyEvent.VK_ENTER);
	  		    Thread.sleep(10000);
	  		}
	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyExpectedtextContainsPassedValues(String PropName,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			String propvalue=getpropvalue(PropName);
	  			propvalue=propvalue.split(";")[1].toString().trim();

	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  				if(Expected.trim().contains((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  		
	  		public  void VerifyExpectedtextContainsPassedValuesFromPropName(String PropName,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  			  				if(str.trim().equalsIgnoreCase((Expected.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}

	  		public  void VerifyExpectedtextFromPropvalue(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			Thread.sleep(5000);
	  			String propvalue=getpropvalue(PropName);
	  			String Expected=TestDataHM.get("Expected");
	  			propvalue=propvalue.split(";")[1].toString().trim();

	  			     String str;
	  			     int counter=0;
	  			     int counter1=0;

	  			   List<WebElement> lst1=driver.findElements(By.xpath("//span"));
	  			     System.out.println(lst1.size());
	  			     for(WebElement we1:lst1) {
	  			    			  str=we1.getText().trim();
	  				if(str.trim().equalsIgnoreCase("No Data"))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is not Find In Application","E");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in application and found No data");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Failed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter++;
		  	                if(counter==lst1.size()) {

	  			     
	  			     
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  				if(str.trim().contains((Expected.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter1++;
	  	                if(counter1==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  	              }
	  			     }
	  			     }
	  					  
	  					          
	  		    
	}	 
	  		
	  		public  void VerifyExpectedtextProp(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			Thread.sleep(5000);
	  			String propvalue=getpropvalue(PropName);
	  			String Expected=TestDataHM.get("Expected");
	  			propvalue=propvalue.split(";")[1].toString().trim();

	  			     String str;
	  			     int counter=0;
			  			     
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  			    			  System.out.println(str);
	  				if(str.trim().equalsIgnoreCase((Expected.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  	              
	  			  
	  					  
	  					          
	  		    
	}	 
	  		
	  		
	  		public  void VerifyExpectedtextFromProp(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			Thread.sleep(5000);
	  			String propvalue=getpropvalue(PropName);
	  			String Expected=TestDataHM.get("Expected");
	  			propvalue=propvalue.split(";")[1].toString().trim();

	  			     String str;
	  			     int counter1=0;

	  			       
	  			     
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  				if(str.trim().contains((Expected.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, Expected+ " Found Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter1++;
	  	                if(counter1==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  	              }
	  			
	  					  
	  					          
	  		    
	  		public static void handleAlert(){
	  		    if(isAlertPresent()){
	  		        Alert alert = driver.switchTo().alert();
	  		        System.out.println(alert.getText());
	  		        alert.accept();
	  		    }
	  		}
	  		public static boolean isAlertPresent(){
	  		      try{
	  		          driver.switchTo().alert();
	  		          return true;
	  		      }catch(NoAlertPresentException ex){
	  		          return false;
	  		      }
	  		}

	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyAttributeValue(String PropName,String Attribute,String WebElement,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			String propvalue=getpropvalue(PropName);
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue+"[contains(@text,'"+WebElement+"')]"));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getAttribute(Attribute).trim();
	  				if(Expected.toLowerCase().trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, PropName+ " Selected Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				break;
	  	            	 
	  	              }
	  	              else{
		  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, Expected+ " Not Found in Application");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  		
	  		
			 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyCountExpectedFromPassedValues(String PropName,String value) throws InterruptedException, IOException, InvalidFormatException{
	  			String Expected=TestDataHM.get("Expected");

	  			String propvalue=getpropvalue(PropName);
	  			     String str;
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue+"[contains(@text,'" +value+"')]"));
	  				 str=String.valueOf(lst.size());
	  			     System.out.println(lst.size());
	  				if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  			test.log(LogStatus.PASS, PropName+ " Selected Successfully");
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				
	  	            	 
	  	              }
	  	              else{
	  	           
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  	  			test.log(LogStatus.FAIL, PropName+ " Not Selected Successfully");
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	            
	  			     
	  					  
	  					          
	  		    
	}
	  		
	  		 //Function to verify Expectedtext/Click and report result to result sheet
	  		public  void VerifyExpectedAttributeandclick(String PropName,String Expected,String Message) throws InterruptedException, IOException, InvalidFormatException{
	  			String propvalue=getpropvalue(PropName);
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath(propvalue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getAttribute("bounds").trim();
	  				if(str.trim().contains((Expected.trim())))
	  	              {
	  	            	we.click();  
	  					imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Message);
                        break;
            	 
	  	              }
	  	              else{
	  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  				    		test.log(LogStatus.FAIL, Expected +" Value Not Validated Successfully");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}	
	  		
	  		
	  		
	  	  //Function to verify Expectedtext/Click and report result to result sheet
	  		public static  boolean VerifyExpectedtextandclick(String PropName,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			//String propvalue=getpropvalue(PropName);
	  			Thread.sleep(1000);
	  			boolean bool=false;
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  			  			     System.out.println(str);

	  				if(str.trim().contains((Expected.trim())))
	  	              {
	  					bool=true;
	  					we.click();  
	  		  			Thread.sleep(1000);
	  					imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Expected +" Value Validated Successfully");
                        break;
            	 
	  	              }
	  	              else{
	  	            	counter++;
	  	                if(counter==lst.size()) {
	  						 // gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						 // String TS=fn_GetTimeStamp();
	  						 // imageNameCounter++;
	  			            	//String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			//String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				//SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			//String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				//xl_WriteResult(ArrSteps);
	  				    		//test.log(LogStatus.FAIL, Expected +" Value Not Validated Successfully");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  //Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  			     return bool;
	  				
	  					  
	  					          
	  		    
	}
	  		
	  		public static  boolean VerifyExpectedExacttextandclick(String PropName,String Expected) throws InterruptedException, IOException, InvalidFormatException{
	  			//String propvalue=getpropvalue(PropName);
	  			Thread.sleep(5000);
	  			//Actions act=new Actions(driver);
	  			//act.sendKeys(Expected).build().perform();
	  			boolean bool=false;
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  			  			     System.out.println(str);

	  				if(str.trim().equalsIgnoreCase(Expected.trim()))
	  	              {
	  		  			//Thread.sleep(1000);
	  		  			//act.sendKeys(we, Keys.TAB).build().perform();

	  				    we.click();  
	  					Thread.sleep(5000);
	  					//imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	//String TS=fn_GetTimeStamp();
	  	            	//String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			//String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				//SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			//String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				//xl_WriteResult(ArrSteps);
	  	  				//Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Expected +" Value Validated Successfully");
                        break;
            	 
	  	              }
	  	              else{
	  	            	counter++;
	  	                if(counter==lst.size()) {
	  						 gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						 // String TS=fn_GetTimeStamp();
	  						 // imageNameCounter++;
	  			            	//String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			//String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				//SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			//String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				//xl_WriteResult(ArrSteps);
	  				    		//test.log(LogStatus.FAIL, Expected +" Value Not Validated Successfully");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  //Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  			     return bool;
	  				
	  					  
	  					          
	  		    
	}

	  		
	  		public static  boolean VerifyExpectedtextandInputValues(String PropName,String Expected,String value) throws InterruptedException, IOException, InvalidFormatException{
	  			//String propvalue=getpropvalue(PropName);
	  			Thread.sleep(5000);
	  			boolean bool=false;
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  				if(str.trim().contains((Expected.trim())))
	  	              {
	  					bool=true;
	  					//we.click(); 
	  					Actions act=new Actions(driver);
	  					act.sendKeys(we, Keys.CLEAR);
	  				    act.sendKeys("Desc").build().perform();

	  					we.sendKeys(value);
	  					imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Expected +" Value Find Successfully");
			    		test.log(LogStatus.PASS, value +" Inserted Successfully");

                        break;
            	 
	  	              }
	  	              else{
	  	            	counter++;
	  	                if(counter==lst.size()) {
	  						 // gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						 // String TS=fn_GetTimeStamp();
	  						 // imageNameCounter++;
	  			            	//String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			//String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				//SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			//String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				//xl_WriteResult(ArrSteps);
	  				    		//test.log(LogStatus.FAIL, Expected +" Value Not Validated Successfully");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  //Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  			     return bool;
	  				
	  					  
	  					          
	  		    
	}
	  	
	  		
			public static  boolean VerifyExpectedtextandInputValue(String PropName,String Expected,String value,int num) throws InterruptedException, IOException, InvalidFormatException{
	  			//String propvalue=getpropvalue(PropName);
	  			Thread.sleep(5000);
	  			boolean bool=false;
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(int i=0;i<=lst.size();i++) {
	  			    	 System.out.println(lst.get(i).getAttribute("id").trim());
	  			    	if(i==num)	{	  
	  					bool=true;
	  					lst.get(num).click(); 
	  					lst.get(num).sendKeys(value);
	  					imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, Expected, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+Expected);
			    		test.log(LogStatus.PASS, Expected +" Value Find Successfully");
			    		test.log(LogStatus.PASS, value +" Inserted Successfully");

                        break;
            	 
	  	              }
	  	              else{
	  	            	counter++;
	  	                if(counter==lst.size()) {
	  						 // gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						 // String TS=fn_GetTimeStamp();
	  						 // imageNameCounter++;
	  			            	//String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			//String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				//SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			//String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				//xl_WriteResult(ArrSteps);
	  				    		//test.log(LogStatus.FAIL, Expected +" Value Not Validated Successfully");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  //Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  			     return bool;
	  				
	  					  
	  					          
	  		    
	}
	  		

  		
	  		
	  	//Function to verify Survey
	  		public  void VerifySurvey() throws InterruptedException, IOException, InvalidFormatException{
	  			     String str;
	  			     int counter=0;
	  		    	WebDriverWait wtObj=new WebDriverWait(driver, 4000);
	  			    String Expected="Survey";
	  				List<WebElement> lst=driver.findElements(By.xpath(prop.getProperty("View")));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  				if(str.trim().contains((Expected.trim())))
	  	              {
	  				    wtObj.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("Button")+"[contains(@text,'clear Skip')]")));
	  	                driver.findElement(By.xpath(prop.getProperty("Button")+"[contains(@text,'clear Skip')]")).click();
	  		    		imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Expected +" Value Find Successfully");
                        break;
            	 
	  	              }
	  	              else{
	  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
	  						wtObj.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("Image")+"[contains(@text,'LogoutFromApp')]")));
	  						wtObj.until(ExpectedConditions.elementToBeClickable(By.xpath(prop.getProperty("Image")+"[contains(@text,'LogoutFromApp')]")));
	  						Thread.sleep(5000);
	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  				    		test.log(LogStatus.FAIL, Expected +" Value Not Find in Application");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  //Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  	 		
	  		
	  		
	  	//Function to Click Checkbox Based on input
	  		public  void ClickOnCheckbox(String PropName,int index) throws InterruptedException, IOException, InvalidFormatException{
	  			String str;
	  			int counter=0;
	  			List<WebElement> lst = null;
	  			String propvalue=getpropvalue(PropName);
	  			String propvalue2=propvalue.split(";")[1].toString();
  		    	WebDriverWait wtObj=new WebDriverWait(driver, 4000);
	  			String propvalue1=propvalue.split(";")[0].toString();
                if(propvalue1.equalsIgnoreCase("name")) {
	  		    lst=driver.findElements(By.name(propvalue));
                }
                if(propvalue1.equalsIgnoreCase("xpath")) {
    	  		    lst=driver.findElements(By.xpath(propvalue));
                    }
	  		    System.out.println(lst.size());
  			    lst.get(index).click();
  			    test.log(LogStatus.PASS, PropName+" selected Successfully");
	  
					          
		    
}
	  		public  void ClickOnCheckboxinRange(String PropName,int startindex,int endindex) throws InterruptedException, IOException, InvalidFormatException{
	  			String str;
	  			int counter=0;
	  			List<WebElement> lst = null;
	  			String propvalue=getpropvalue(PropName);
	  			String propvalue2=propvalue.split(";")[1].toString();
  		    	WebDriverWait wtObj=new WebDriverWait(driver, 4000);
	  			String propvalue1=propvalue.split(";")[0].toString();
                if(propvalue1.equalsIgnoreCase("name")) {
	  		    lst=driver.findElements(By.name(propvalue2));
                }
                if(propvalue1.equalsIgnoreCase("xpath")) {
    	  		    lst=driver.findElements(By.xpath(propvalue2));
                    }
	  		    System.out.println(lst.size());
	  		    for(int i=startindex;i<=endindex;i++) {
  			    lst.get(i).click();
  			    test.log(LogStatus.PASS, "Checkbox from "+ startindex + endindex+" selected Successfully");
	  		    }
	  
					          
		    
}
	  		
	  		public  void ClickOnWebElementWithIndex(String Type,String value,int index) throws InterruptedException, IOException, InvalidFormatException{
	  			String str;
	  			int counter=0;
	  		    List<WebElement> lst=driver.findElements(By.xpath(prop.getProperty(Type)+"[contains(@text,'"+value+"')]"));
	  			     System.out.println(lst.size());
	  			    lst.get(index).click();
	  			    test.log(LogStatus.PASS, value+" selected Successfully");
   	 Thread.sleep(5000);
	  	             }	  
	  					  
	  	           
	  				
	  					  
	  					          
	  		    
	
	  	//Function to Click Checkbox Based on input
	  		public  void SelectCheckbox(int index) throws InterruptedException, IOException, InvalidFormatException{
	  			String str;
	  			int counter=0;
	  		    List<WebElement> lst=driver.findElements(By.xpath("//android.widget.CheckBox"));
	  			     System.out.println(lst.size());
  			    	 if(lst.get(index).getAttribute("checked").equalsIgnoreCase("false")) {
	  			    		lst.get(index).click();
		  	            	gm_WriteToLog(" Checkboxes are selected","I");
	  					Reporter.log("Validation Passed. Where Expected-"+"Checkboxes are selected"+", Actual-"+"Checkboxes are selected");
			    		test.log(LogStatus.PASS, "Checkboxes are selected");
   	 
	  	              }
	  	              else{
	  	            	gm_WriteToLog(" Checkboxes are by default  selected","I");
	  	  				Reporter.log("Validation Passed. Where Expected-"+"Checkboxes are by default selected"+", Actual-"+"Checkboxes are not selected");
			    		test.log(LogStatus.PASS, "All Checkboxes are ByDefault selected");
   	 
	  	             }	  
	  					  
 				
	  					  
	  					          
	  		    
	  		}
	
	  		

	  		
	  	//Function to verify Expectedtext/Click and report result to result sheet
	  		public  void VerifyActualContainsExpectedtext(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			Thread.sleep(5000);
	  			//String propvalue=getpropvalue(PropName);
	  			String Expected=TestDataHM.get("Expected");
	  			     String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			    			  str=we.getText().trim();
	  			  			     System.out.println(str);

	  				if(str.trim().contains((Expected.trim())))
	  	              {
	  					imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, str +" Value Validated Successfully");
			    		break;

	  	            	 
	  	              }
	  	              else{
	  	            	counter++;
	  	                if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  				    		test.log(LogStatus.FAIL, str +" Value Not Validated Successfully");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  				
	  					  
	  					          
	  		    
	}
	  		
	  
			//Function to verify Expectedtext/Click and report result to result sheet
	  		public static  void VerifyAlertText() throws InterruptedException, IOException, InvalidFormatException{
	  			Thread.sleep(3000);
	  			String Expected=TestDataHM.get("Expected");
	  			 String str;
	  			     int counter=0;
	 	  			Alert alert = driver.switchTo().alert();
		  			str=alert.getText();
	  		        System.out.println(str);
	  			    if(str.trim().contains(Expected.trim()))
	  	              {
					    alert.accept();
						test.log(LogStatus.PASS, "Alert Closed Successfully");
	  			    	imageNameCounter++;
	  	            	gm_WriteToLog("Alert: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected,str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, "Alert: " +Expected+ " is Find In Application");
	  	            	 
	  	              }
	  	              else{
	  						  gm_WriteToLog("Alert: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected,str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  				    		test.log(LogStatus.FAIL, "Alert: " +Expected+ " is not Find In Application");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  				
	  					  
	  					          
	  		    
	}		
	  	//Function to verify Expectedtext/Click and report result to result sheet
	  		public  void VerifySelectedCheckBoxValue(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			Thread.sleep(5000);
	  			//String propvalue=getpropvalue(PropName);
	  			String Expected=TestDataHM.get("Expected");
  				String PropValue=prop.getProperty(PropName);
  				PropValue=PropValue.split(";")[1].toString().trim();
	  			 String str;
	  			     int counter=0;
	  				List<WebElement> lst=driver.findElements(By.xpath(PropValue));
	  			     System.out.println(lst.size());
	  			    if(String.valueOf(lst.size()).equalsIgnoreCase(Expected))
	  	              {
	  					imageNameCounter++;
	  	            	gm_WriteToLog("Total Selected Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, String.valueOf(lst.size()), "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+String.valueOf(lst.size()));
			    		test.log(LogStatus.PASS, "Total Selected Value: " +Expected+ " is Find In Application");
	  	            	 
	  	              }
	  	              else{
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected,String.valueOf(lst.size()), "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  				    		test.log(LogStatus.FAIL, "Total Selected Value: " +Expected+ " is not Find In Application");

	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  				
	  					  
	  					          
	  		    
	}		
	  		 //Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyBlankValuesLoginExpectedtext(String PropName) throws InterruptedException, IOException, InvalidFormatException{
       	  			String Expected=TestDataHM.get("Expected").trim().toLowerCase();
       	  		    Expected=Expected.split("=")[1];
	  			     String str;
	  				 str=driver.findElement(By.xpath(prop.getProperty(PropName))).getAttribute("enabled");
	  				System.out.println(str);
	  				System.out.println(Expected);
	  				 if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
	  	  				Assert.assertEquals(str, Expected, TestName+" being Validated");	 
	  	            	 
	  	              }
	  	              else{

	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");

	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }

	  					  
	  					          
	  		    
	}
	  		
	  	//Function to verify Expectedtext and report result to result sheet
	  		public  void VerifyLoginExpectedtext(String PropName,int rownum) throws InterruptedException, IOException, InvalidFormatException{
  			    xl_GetData(rownum);	
	  			String Expected=TestDataHM.get("Expected");
	  				String PropValue=prop.getProperty(PropName);
	  			     String str;
	  			     int counter=0;
	  			     List<WebElement> lst=driver.findElements(By.xpath(PropValue));
	  			     for(WebElement we:lst) {
	  			  str=we.getText().trim();
	  			     if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	  
	  			    	 imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Expected +" Value Validated Successfully");
	  	  				Assert.assertEquals(str, Expected, TestName+" being Validated");	 
	  	            	 
	  	              }
	  	              else{
                            counter++;
                            if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
		  			   	      WebDriverWait wtObj=new WebDriverWait(driver, 300);	
	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  				    		test.log(LogStatus.FAIL, Expected +" Value Not Validated Successfully");
	  				    	  wtObj.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("Button")+"[contains(@text,'OK')]")));
		 	  				  driver.findElement(By.xpath(prop.getProperty("Button")+"[contains(@text,'OK')]")).click();

	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  			     if(Expected.equalsIgnoreCase("Service Desk")) {
	  			    	WebDriverWait wtObj=new WebDriverWait(driver, 600);	
	  					wtObj.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("View")+"[contains(@text,'Service Desk')]")));
                    	Thread.sleep(10000);

	  			     }
	  			     else {
	  			   	      WebDriverWait wtObj=new WebDriverWait(driver, 300);	
	  					  wtObj.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("Button")+"[contains(@text,'OK')]")));
	 	  				  driver.findElement(By.xpath(prop.getProperty("Button")+"[contains(@text,'OK')]")).click();

	  			     }
	  			    	
	  					          
	  		    
	}
	  		
	  	//Function to verify Expectedtext and report result to result sheet
	  		public  void ClickValueFromPassedInput(String PropName,String Value) throws InterruptedException, IOException, InvalidFormatException{
	  			String Expected=TestDataHM.get(Value);
	  			     String str;
	  			     int counter=0;
	  			     List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
	  			     for(WebElement we:lst) {
	  			     str=we.getText().trim();
	  			     if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	 we.click();
	  			    	 imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Expected +" Value Clicked Successfully");
	  	  				Assert.assertEquals(str, Expected, TestName+" being Validated");
	  	  				if(str.equalsIgnoreCase("CBRE | FacilitySource")) {
		  	  				Thread.sleep(15000);

	  	  				}
	  	  				Thread.sleep(5000);
	  	  				break;
	  	              }
	  	              else{
                            counter++;
                            if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
		  			   	      WebDriverWait wtObj=new WebDriverWait(driver, 300);	
	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  				    		test.log(LogStatus.FAIL, Expected +" Value Not Clicked Successfully");
	  				    	  wtObj.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("Button")+"[contains(@text,'OK')]")));
		 	  				  driver.findElement(By.xpath(prop.getProperty("Button")+"[contains(@text,'OK')]")).click();

	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  			     
	  					          
	  		    
	}
	  
	  		//Function to verify Expectedtext and report result to result sheet
	  		public  void FindValueFromTable(String PropName) throws InterruptedException, IOException, InvalidFormatException{
	  			String Expected=TestDataHM.get("Expected");
  				String PropValue=prop.getProperty(PropName);
  				PropValue=PropValue.split(";")[1].toString().trim();
	  			     String str;
	  			     int counter=0;
	  			     List<WebElement> lst=driver.findElements(By.xpath(PropValue));
	  			     System.out.println(lst.size());
	  			     for(WebElement we:lst) {
	  			     str=we.getText().trim();
	  			     if(Expected.trim().equalsIgnoreCase((str.trim())))
	  	              {
	  	            	// we.click();
	  			    	 imageNameCounter++;
	  	            	gm_WriteToLog(" Value: " +Expected+ " is Find In Application","I");
	  	            	String TS=fn_GetTimeStamp();
	  	            	String TestName=gm_TestCaseName("Test_Case_Name");
	  	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  	  				
	  	  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
	  	  				xl_WriteResult(ArrSteps);
	  	  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    		test.log(LogStatus.PASS, Expected +" Value found Successfully");
	  	  				Assert.assertEquals(str, Expected, TestName+" being Validated");	 
	  	            	 break;
	  	              }
	  	              else{
                            counter++;
                            if(counter==lst.size()) {
	  						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
		  			   	      WebDriverWait wtObj=new WebDriverWait(driver, 300);	
	  						  String TS=fn_GetTimeStamp();
	  						  imageNameCounter++;
	  			            	String TestName=gm_TestCaseName("Test_Case_Name");
	  			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  			  				
	  			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	  			  				xl_WriteResult(ArrSteps);
	  							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	  				    		test.log(LogStatus.FAIL, Expected +" Value Not found Successfully");
	  				    	  wtObj.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getProperty("Button")+"[contains(@text,'OK')]")));

	  							  Assert.fail("Value Not Found");	 
	  					   
	  						  
	  					  }
	  	              }
	  			     }
	  			     
	  					          
	  		    
	}
	  	//Function to Click Checkbox Based on input
	  		public  void SelectEditText(int index,String Message) throws InterruptedException, IOException, InvalidFormatException{
	  			String str;
	  			int counter=0;
	  		    List<WebElement> lst=driver.findElements(By.xpath("//android.widget.EditText"));
	  			     System.out.println(lst.size());
	  			    		lst.get(index).click();

	  			    		//driver.getKeyboard().sendKeys(value);
		  	            gm_WriteToLog(" Editbox are selected","I");
	  					Reporter.log("Validation Passed. Where Expected-"+"Checkboxes are selected"+", Actual-"+"Checkboxes are selected");
			    		test.log(LogStatus.PASS, Message);
   	 
	  					          
	  		    
	}	
	  		
	
	  
	
	  		public void VerifyExpectedData(String PropName) throws InvalidFormatException, IOException, InterruptedException {
	  			String Expected=TestDataHM.get("Expected");
			    String elem="";
			    int count=0;
			    String str="";
			    String[] array=Expected.split(";");
			    for(int i=0;i<=array.length-1;i++) {
				    int counter=0;
			    	elem=array[i].trim();
			    	List<WebElement> lst=driver.findElements(By.xpath("//"+ PropName));
	 			     for(WebElement we:lst) {
	 			    			  str=we.getText().trim();
	 				if(elem.trim().equalsIgnoreCase((str.trim())))
	 	              {
	 	            	  
		            	  gm_WriteToLog(elem+ " Found Successfully","I");
	 					  test.log(LogStatus.PASS, elem+ " Found Successfully");
	 	  			   	  Reporter.log("Validation Passed. Where Expected-"+elem+", Actual-"+str);
	 	  			   	  count++;
	 	  				  break;
	 	            	 
	 	              }
	 	              else{
	 	                if(counter==lst.size()) {
	 						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
	 	 	            	  test.log(LogStatus.PASS, elem+ " Not Found Successfully");
	 						  String TS=fn_GetTimeStamp();
	 						  imageNameCounter++;
	 			            	String TestName=gm_TestCaseName("Test_Case_Name");
	 			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 			  	  			test.log(LogStatus.FAIL, PropName+ " Not Selected Successfully");
	 			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	 			  				xl_WriteResult(ArrSteps);
	 							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	 							  Assert.fail("Value Not Found");	 
	 					   
	 						  
	 					  }
	 	            	counter++;

	 	              }
			    }

			    }
			    if (count==array.length) {
			    	imageNameCounter++;
		            	gm_WriteToLog("All Values: "+Expected+" are Find In Application","I");
		            	String TS=fn_GetTimeStamp();
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  			test.log(LogStatus.PASS, "All Values: "+Expected+" are Find In Application");
		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
		  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    }
			    
		 }
	
	  		public void VerifyExpectedDataContainsValue(String PropName) throws InvalidFormatException, IOException, InterruptedException {
			    String Expected=TestDataHM.get("Expected");
			    String elem="";
			    int count=0;
			    String str="";
			    String[] array=Expected.split(";");
			    for(int i=0;i<=array.length-1;i++) {
				    int counter=0;
			    	elem=array[i].trim();
			    	List<WebElement> lst=driver.findElements(By.xpath("//"+ PropName));
	 			     for(WebElement we:lst) {
	 			    			  str=we.getText().trim();
	 				if(str.trim().contains((elem.trim())))
	 	              {
	 	            	  
		            	  gm_WriteToLog(elem+ " Found Successfully","I");
	 					  test.log(LogStatus.PASS, elem+ " Found Successfully");
	 	  			   	  Reporter.log("Validation Passed. Where Expected-"+elem+", Actual-"+str);
	 	  			   	  count++;
	 	  				  break;
	 	            	 
	 	              }
	 	              else{
	 	                if(counter==lst.size()) {
	 						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
	 	 	            	  test.log(LogStatus.PASS, elem+ " Not Found Successfully");
	 						  String TS=fn_GetTimeStamp();
	 						  imageNameCounter++;
	 			            	String TestName=gm_TestCaseName("Test_Case_Name");
	 			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 			  	  			test.log(LogStatus.FAIL, PropName+ " Not Selected Successfully");
	 			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	 			  				xl_WriteResult(ArrSteps);
	 							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	 							  Assert.fail("Value Not Found");	 
	 					   
	 						  
	 					  }
	 	            	counter++;

	 	              }
			    }

			    }
			    if (count==array.length) {
			    	imageNameCounter++;
		            	gm_WriteToLog("All Values: "+Expected+" are Find In Application","I");
		            	String TS=fn_GetTimeStamp();
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  			test.log(LogStatus.PASS, "All Values: "+Expected+" are Find In Application");
		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
		  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    }
			    
		 }
	  		public void VerifyExpectedDataWithPropValue(String PropName) throws InvalidFormatException, IOException, InterruptedException {
			    String Expected=TestDataHM.get("Expected");
			    String PropValue=prop.getProperty(PropName);
  				PropValue=PropValue.split(";")[1].toString().trim();
	  		
			    String elem="";
			    int count=0;
			    String str="";
			    String[] array=Expected.split(";");
			    for(int i=0;i<=array.length-1;i++) {
				    int counter=0;
			    	elem=array[i].trim();
			    	List<WebElement> lst=driver.findElements(By.xpath(PropValue));
	 			     for(WebElement we:lst) {
	 			    			  str=we.getText().trim();
	 				if(elem.trim().equalsIgnoreCase((str.trim())))
	 	              {
	 	            	  
		            	  gm_WriteToLog(elem+ " Found Successfully","I");
	 					  test.log(LogStatus.PASS, elem+ " Found Successfully");
	 	  			   	  Reporter.log("Validation Passed. Where Expected-"+elem+", Actual-"+str);
	 	  			   	  count++;
	 	  				  break;
	 	            	 
	 	              }
	 	              else{
	 	                if(counter==lst.size()) {
	 						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
	 	 	            	  test.log(LogStatus.PASS, elem+ " Not Found Successfully");
	 						  String TS=fn_GetTimeStamp();
	 						  imageNameCounter++;
	 			            	String TestName=gm_TestCaseName("Test_Case_Name");
	 			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 			  	  			test.log(LogStatus.FAIL, PropName+ " Not Selected Successfully");
	 			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	 			  				xl_WriteResult(ArrSteps);
	 							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	 							  Assert.fail("Value Not Found");	 
	 					   
	 						  
	 					  }
	 	            	counter++;

	 	              }
			    }

			    }
			    if (count==array.length) {
			    	imageNameCounter++;
		            	gm_WriteToLog("All Values: "+Expected+" are Find In Application","I");
		            	String TS=fn_GetTimeStamp();
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  			test.log(LogStatus.PASS, "All Values: "+Expected+" are Find In Application");
		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
		  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    }
			    
		 }
	  		public void VerifyExpectedDataWithAttribute(String PropName,String Attribute) throws InvalidFormatException, IOException, InterruptedException {
			    String Expected=TestDataHM.get("Expected");
			    String elem="";
			    int count=0;
			    String str="";
			    String[] array=Expected.split(";");
			    for(int i=0;i<=array.length-1;i++) {
				    int counter=0;
			    	elem=array[i].trim();
			    	List<WebElement> lst=driver.findElements(By.xpath("//"+ PropName));
	 			     for(WebElement we:lst) {
	 			    			  str=we.getAttribute(Attribute).trim();
	 				if(str.trim().contains((elem.trim())))
	 	              {
	 	            	  
		            	  gm_WriteToLog(elem+ " Found Successfully","I");
	 					  test.log(LogStatus.PASS, elem+ " Found Successfully");
	 	  			   	  Reporter.log("Validation Passed. Where Expected-"+elem+", Actual-"+str);
	 	  			   	  count++;
	 	  				  break;
	 	            	 
	 	              }
	 	              else{
	 	                if(counter==lst.size()) {
	 						  gm_WriteToLog("Value: " +Expected+ " is Not Find IN Application","E");
	 	 	            	  test.log(LogStatus.PASS, elem+ " Not Found Successfully");
	 						  String TS=fn_GetTimeStamp();
	 						  imageNameCounter++;
	 			            	String TestName=gm_TestCaseName("Test_Case_Name");
	 			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 			  	  			test.log(LogStatus.FAIL, PropName+ " Not Selected Successfully");
	 			  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Failed", SnapshotPath, 3);
	 			  				xl_WriteResult(ArrSteps);
	 							  Reporter.log("Value Matching Failed. Where RR-"+Expected+" Not Found In Application");
	 							  Assert.fail("Value Not Found");	 
	 					   
	 						  
	 					  }
	 	            	counter++;

	 	              }
			    }

			    }
			    if (count==array.length) {
			    	imageNameCounter++;
		            	gm_WriteToLog("All Values: "+Expected+" are Find In Application","I");
		            	String TS=fn_GetTimeStamp();
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  			test.log(LogStatus.PASS, "All Values: "+Expected+" are Find In Application");
		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected, str, "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
		  				Reporter.log("Validation Passed. Where Expected-"+Expected+", Actual-"+str);
			    }
			    
		 }
	    @AfterTest
	    
	    public void tearDown() throws Exception { 


	        if(driver != null){
	            driver.quit();
	        }
	    }
	    
	    /*
	     *  This test launches the apiDemos Android application and navigates within it.
	     */
	  
	    
	    
	  
	 
		
		
	    
		//Function is used to configure log4j
		public static void gm_ConfigureLog4J() throws IOException{
			Properties p = new Properties();
			  //String log4jPath=gm_GetConfigValue("log4JPropPath");
		       p.load(new FileInputStream(ConfigFilePath));
		       PropertyConfigurator.configure(p);
		}
		
		//Function to write logging into text file,console and for html file
		public static  void gm_WriteToLog(String Msg, String LogType) throws IOException{
			  gm_ConfigureLog4J();
			  Logger logger = Logger.getLogger(LogType);
			  if(LogType.equalsIgnoreCase("I")){
					logger.info(Msg);
			  }else if(LogType.equalsIgnoreCase("D")){
					logger.debug(Msg);
			  }else if(LogType.equalsIgnoreCase("E")){
					logger.error(Msg);
			  }else if(LogType.equalsIgnoreCase("W")){
					logger.warn(Msg);
			  }

		}
		
		//Function to write logging into text file,console and for html file on the basis of classes
		public  void gm_WriteToLog(String Msg,String LogType, String ClassName) throws IOException{
			ConfigObject=new Properties();
			FileInputStream fis=new FileInputStream(ConfigFilePath);
			ConfigObject.load(fis);
		}
		//Function to check visibility 
		public static boolean gm_checkVisibility(WebElement we) throws IOException, InvalidFormatException{
			boolean status=false;
			int hght=0;
			try{
				status=we.isDisplayed();
				hght=we.getSize().getHeight();
			}catch(NoSuchElementException ne){
				status=gm_CustomWait(we, 40);
				if(status==false){
					ne.printStackTrace();
					//Assert.assertEquals(false,true);
					 String TS=fn_GetTimeStamp();
					 imageNameCounter++;
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  			String str1=" WebElement: " +we+ " is Not Find in Application";
		  			String Value=" WebElement: " +we+ " is Find in Application";
		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str1, "Failed", SnapshotPath, 3);
		  			xl_WriteResult(ArrSteps);
					  gm_WriteToLog(" WebElement: " +we+ " is Not Find in Application","E");
					  Reporter.log(" WebElement: " +we+ " is Not Find in Application");
					  Assert.fail(" WebElement: " +we+ " is Not Find in Application");
				}
			}
			
			if(status==true && hght>0){
				Assert.assertEquals(true, true);
				return true;

			}else{
				//Assert.assertEquals(false,true);
				String TS=fn_GetTimeStamp();
				imageNameCounter++;
	        	String TestName=gm_TestCaseName("Test_Case_Name");
				String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
					SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
				String str1=" WebElement: " +we+ " is Not Visible in Application";
				String Value=" WebElement: " +we+ " is Visible in Application";
				String[] ArrSteps=gm_GetResultStepArray(TestName, Value, str1, "Failed", SnapshotPath, 3);
				xl_WriteResult(ArrSteps);
			  gm_WriteToLog(" WebElement: " +we+ " is Not Visible in Application","E");
			  Reporter.log(" WebElement: " +we+ " is Not Visible in Application");
			  Assert.fail(" WebElement: " +we+ " is Not Visible in Application");
				return false;
			}
		  
			
		}
		
		//Function to get step array with snapshot
				public static  String[] gm_GetResultStepArray(String ElementName,String exp,String ActualText,String Status, String SnapshotPath, int testcaseindex){
					String[] ResultArray=gm_GetResultStepArray(ElementName,exp,ActualText,Status,testcaseindex);
					int itemcount=ResultArray.length;
					String[] Up_ResultArray=new String[itemcount+1];
					Up_ResultArray=new ArrayUtils().add(ResultArray, SnapshotPath);
					//new String[];
					return Up_ResultArray;
				}
				
				//Function to get step array without  snapshot
				public static  String[] gm_GetResultStepArray(String ElementName,String exp,String ActualText,String Status, int testcaseindex){
				      Throwable t=new Throwable();
				      StackTraceElement[] arr_Ste=t.getStackTrace();
				      StackTraceElement ste=arr_Ste[testcaseindex];
				      String MethodName=ste.getMethodName();
				      String ClassName=ste.getClassName();
				      String[]ArrClsName=ClassName.split("\\.");
				      String SubModuleName=ArrClsName[ArrClsName.length-1];
				      String ModuleName=ArrClsName[ArrClsName.length-1];
				      String[] ResultArray={ModuleName, SubModuleName,ElementName, MethodName, exp, ActualText, Status}; 
				      return ResultArray;
				}
				
		//Function to Select user based test case name
		public static String gm_TestCaseName(String ColumnName) throws IOException{
			String tdValue=TestDataHM.get(ColumnName);
			return tdValue;
					
		}
		
		
		//Function to Select user based Expected name
				public String gm_ExpectedName(String ColumnName) throws IOException{
					String tdValue=TestDataHM.get(ColumnName);
					return tdValue;
							
				}
		
		
		
		//Function to take snapshots
		public static  String fn_TakeSnapshot(WebDriver driver, String DestFilePath) throws IOException{
			String TS=fn_GetTimeStamp();
			TakesScreenshot tss=(TakesScreenshot) driver;
	   	    File srcfileObj= tss.getScreenshotAs(OutputType.FILE);
	   	    DestFilePath=DestFilePath+TS+".png";
	   	    File DestFileObj=new File(DestFilePath);
	   	    FileUtils.copyFile(srcfileObj, DestFileObj);
	   	    return DestFilePath;
		}
		
		//Function to get timestamp
		public static  String fn_GetTimeStamp(){
			DateFormat DF=DateFormat.getDateTimeInstance();
			Date dte=new Date();
			String DateValue=DF.format(dte);
			DateValue=DateValue.replaceAll(":", "_");
			DateValue=DateValue.replaceAll(",", "");
			return DateValue;
		}
						
		//Function to check enable
		public static boolean gm_checkEnabled(WebElement we){
			boolean status=we.isEnabled();
			return status;
			
		}
	    
		public boolean textValidation(String text, int timeout) {
	        try {
	            (new WebDriverWait(driver, timeout)).
	            until(ExpectedConditions.visibilityOfElementLocated(
	                    By.xpath("//*[@label='" + text + "']")));
	        } catch (TimeoutException e) {
	            return false;
	        }
	        return true;
	    }
	    
		
		public static WebElement CreateWebElement(String LocatorPath ) throws InvalidFormatException, IOException, InterruptedException {
			WebElement we=null;
			String LocatorType=LocatorPath.split(";")[0].toString().trim();
			LocatorPath=LocatorPath.split(";")[1].toString().trim();
			
			if(LocatorType.equalsIgnoreCase("name")) {
				we=driver.findElement(By.name(LocatorPath));

			}
			if(LocatorType.equalsIgnoreCase("id")) {
				we=driver.findElement(By.id(LocatorPath));

			}
			if(LocatorType.equalsIgnoreCase("xpath")) {
				we=driver.findElement(By.xpath(LocatorPath));

			}
			if(LocatorType.equalsIgnoreCase("linktext")) {
				we=driver.findElement(By.linkText(LocatorPath));

			}
			return we;
				}
		
		
	
		public void ClickOnWebElement(String PropName) throws InvalidFormatException, IOException, InterruptedException {
			
			gm_Click(PropName);
			if(!PropName.equalsIgnoreCase("equipmentdropdown")) {
				Thread.sleep(5000);
			}
			if(PropName.equalsIgnoreCase("deleteinvoice")) {
				Thread.sleep(8000);

			}
			if(PropName.equalsIgnoreCase("quotedelete")) {
				Thread.sleep(8000);

			}
			
		
				}	
		
		public void LogOut() throws InvalidFormatException, IOException, InterruptedException {
			  WaitForWebElement("logout");
			  ClickOnWebElement("logout");
			  WaitForWebElement("username");

		}
		
		public void ClickandClearContents(String PropName) throws InvalidFormatException, IOException, InterruptedException {
			gm_ClickandClearContents(PropName);
			Thread.sleep(3000);
		
				}	
		public static void WaitForWebElement(String PropName) throws InvalidFormatException, IOException, InterruptedException {
	 		 
			gm_WaitVIsibility(PropName, 1200000);
		
				}	
		
		public void ClickOnWebElementWithInput(String PropName,String Value) throws InvalidFormatException, IOException, InterruptedException {
		    String Expected=TestDataHM.get(Value);
		    String str="";
		    int counter=0;
		    String PropValue=prop.getProperty(PropName);
			PropValue=PropValue.split(";")[1].toString().trim();
  		    List<WebElement> lst=driver.findElements(By.xpath(PropValue));
			int Count=lst.size();
			System.out.println(Count);
			String value=String.valueOf(Count);
			for(WebElement we:lst) {
	    			  str=we.getText().trim();
	    		if(str.equalsIgnoreCase(Expected)) {
	    			we.click();
	    			  gm_WriteToLog("Value: "+Value+ "selected Succesfully from Application","I");
    				  String TS=fn_GetTimeStamp();
					  imageNameCounter++;
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  				
		  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  Expected+" Found in application",  Expected+" Found in application", "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
						  Reporter.log("Value: "+Value+ "selected Succesfully from Application");
			    		test.log(LogStatus.PASS, "Value: "+Value+ "selected Succesfully from Application");

						  break;
				   	}
	    		 else{
		 	           	counter++;
	 	                if(counter==Count) {
	 	                	 imageNameCounter++;
	 		            	gm_WriteToLog("Value: "+Value+ "not selected Succesfully from Application","E");
	 		            	String TS=fn_GetTimeStamp();
	 		            	String TestName=gm_TestCaseName("Test_Case_Name");
	 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 		  				
	 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected+"Not Found in application", Expected+"Not Found in application", "Passed", SnapshotPath, 3);
	 		  				xl_WriteResult(ArrSteps);
	 		  				Reporter.log("Validation Failed. Where Expected- ,"+ Expected+"Not Found in application"+ "Actual-"+ Expected+"Not Found in application");
	 		    		test.log(LogStatus.FAIL, "Value: "+Value+ " not selected Succesfully from Application");
	 		  				Assert.assertEquals( Expected+"Not Found in application",  Expected+"Not Found in application", TestName+" being Validated");
	 			 
				   
			}
	    		 }
			}
		
				}
		public static void WindowTabOpen() {
		      driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t");
		      ((JavascriptExecutor)driver).executeScript("window.open()");
	    		test.log(LogStatus.PASS, "Tab opened Successfully");

		}
		
		public static void SwitchToTab(ArrayList<String> tabs,int number) throws InterruptedException {
			
		      driver.switchTo().window(tabs.get(number));
	    		test.log(LogStatus.PASS, "Tab Switch Successfully");
	    		Thread.sleep(2000);


		}
		
		public void ClickOnWebElementWithInputtag(String PropName,String Value) throws InvalidFormatException, IOException, InterruptedException {
		    String Expected=TestDataHM.get(Value);
		    String str="";
		    int counter=0;
  		    List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
			int Count=lst.size();
			System.out.println(Count);
			//String value=String.valueOf(Count);
			for(WebElement we:lst) {
	    			  str=we.getText().trim();
	    			  System.out.println(str);

	    		if(str.equalsIgnoreCase(Expected.toString().trim())) {
	    			we.click();
	    			  gm_WriteToLog("Value: "+Value+ "selected Succesfully from Application","I");
    				  String TS=fn_GetTimeStamp();
					  imageNameCounter++;
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  				
		  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  Expected+" Found in application",  Expected+" Found in application", "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
						  Reporter.log("Value: "+Value+ "selected Succesfully from Application");
			    		test.log(LogStatus.PASS, "Value: "+Value+ "selected Succesfully from Application");

						  break;
				   	}
	    		 else{
		 	           	counter++;
	 	                if(counter==Count) {
	 	                	 imageNameCounter++;
	 		            	gm_WriteToLog("Value: "+Value+ "not selected Succesfully from Application","E");
	 		            	String TS=fn_GetTimeStamp();
	 		            	String TestName=gm_TestCaseName("Test_Case_Name");
	 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 		  				
	 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected+"Not Found in application", Expected+"Not Found in application", "Passed", SnapshotPath, 3);
	 		  				xl_WriteResult(ArrSteps);
	 		  				Reporter.log("Validation Failed. Where Expected- ,"+ Expected+"Not Found in application"+ "Actual-"+ Expected+"Not Found in application");
	 		    		test.log(LogStatus.FAIL, "Value: "+Value+ " not selected Succesfully from Application");
	 		  				Assert.assertEquals( Expected+"Not Found in application",  Expected+"Not Found in application", TestName+" being Validated");
	 			 
				   
			}
	    		 }
			}
		
				}	
		

		public static String GetElementWithFieldType(String PropName,String FieldType) throws InvalidFormatException, IOException, InterruptedException {
		    //String PropValue=prop.getProperty(PropName);
		    String str,strvalue="";
		    int counter=0;
  		    List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
			int Count=lst.size();
			System.out.println(Count);
			//String value=String.valueOf(Count);
			for(int i=1;i<=Count;i++) {
				
	    			  str=lst.get(i).getText().trim();
	    			  System.out.println(str);
	    		if(str.equalsIgnoreCase(FieldType.trim())) {
	    			  strvalue=lst.get(i+1).getText().trim();
	    			  gm_WriteToLog("Value: "+strvalue+ "Found Succesfully from Application","I");
    				  String TS=fn_GetTimeStamp();
					  imageNameCounter++;
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  				
		  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  FieldType+" Found in application",  str+" Found in application", "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
						  Reporter.log("Value: "+strvalue+ "found Succesfully from Application");
			    		test.log(LogStatus.PASS, "Value: "+strvalue+ "found Succesfully from Application");

						  break;
				   	}
	    		 else{
		 	           	counter++;
	 	                if(counter==Count) {
	 	                	 imageNameCounter++;
	 		            	gm_WriteToLog("Value: "+strvalue+ "not found Succesfully from Application","E");
	 		            	String TS=fn_GetTimeStamp();
	 		            	String TestName=gm_TestCaseName("Test_Case_Name");
	 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 		  				
	 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, FieldType+"Not Found in application", str+"Not Found in application", "Passed", SnapshotPath, 3);
	 		  				xl_WriteResult(ArrSteps);
	 		  				Reporter.log("Validation Failed. Where Expected- ,"+ FieldType+"Not Found in application"+ "Actual-"+ str+"Not Found in application");
	 		    		test.log(LogStatus.FAIL, "Value: "+strvalue+ " not found Succesfully from Application");
	 		  				Assert.assertEquals( FieldType+"Not Found in application",  str+"Not Found in application", TestName+" being Validated");
	 			 
				   
			}
	    		 }
			}
		return strvalue;
				}	
		
		public void VerifyElementWithFieldType(String PropName,String FieldType,String value) throws InvalidFormatException, IOException, InterruptedException {
		    //String PropValue=prop.getProperty(PropName);
		    String str,strvalue="";
		    int counter=0;
  		    List<WebElement> lst=driver.findElements(By.xpath("//"+PropName));
			int Count=lst.size();
			System.out.println(Count);
			//String value=String.valueOf(Count);
			for(int i=1;i<=Count;i++) {
				
	    			  str=lst.get(i).getText().trim();
	    			  System.out.println(str);
	    		if(str.equalsIgnoreCase(FieldType.trim())) {
	    			  strvalue=lst.get(i+1).getText().trim();
	    			  if(value.trim().equalsIgnoreCase(strvalue.trim())) {
	    			  gm_WriteToLog("Value: "+strvalue+ "for field type: "+FieldType+" Found Succesfully from Application","I");
    				  String TS=fn_GetTimeStamp();
					  imageNameCounter++;
		            	String TestName=gm_TestCaseName("Test_Case_Name");
		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		  				
		  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  FieldType+" Found in application",  str+" Found in application", "Passed", SnapshotPath, 3);
		  				xl_WriteResult(ArrSteps);
						  Reporter.log("Value: "+strvalue+ "found Succesfully from Application");
			    		test.log(LogStatus.PASS, "Value: "+strvalue+ " for field type: "+FieldType+" Found Succesfully from Application");

						  break;
	    			  }
	    			  else {
	    				  
				    test.log(LogStatus.FAIL, "Value: "+value+ " for field type: "+FieldType+" Not  Found Succesfully from Application");

	    			  }
				   	}
	    		 else{
		 	           	counter++;
	 	                if(counter==Count) {
	 	                	 imageNameCounter++;
	 		            	gm_WriteToLog("Value: "+strvalue+ "not found Succesfully from Application","E");
	 		            	String TS=fn_GetTimeStamp();
	 		            	String TestName=gm_TestCaseName("Test_Case_Name");
	 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 		  				
	 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, FieldType+"Not Found in application", value+"Not Found in application", "Passed", SnapshotPath, 3);
	 		  				xl_WriteResult(ArrSteps);
	 		  				Reporter.log("Validation Failed. Where Expected- ,"+ FieldType+"Not Found in application"+ "Actual-"+ str+"Not Found in application");
	 		    		test.log(LogStatus.FAIL, "Value: "+value+ " not found Succesfully from Application");
	 		  				Assert.assertEquals( FieldType+"Not Found in application",  value+"Not Found in application", TestName+" being Validated");
	 			            Assert.fail("Value: "+value+ " not found Succesfully from Application");
				   
			}
	    		 }
			}
				}	

	
		
		public void SelectTicketFromMP(String WorkOrder,String value) throws InvalidFormatException, IOException, InterruptedException {
		    String str,strvalue="";
		    int counter=0;
  		    List<WebElement> lst=driver.findElements(By.xpath("//a"));
			int Count=lst.size();
			System.out.println(Count);
			//String value=String.valueOf(Count);
			for(int i=1;i<=Count;i++) {
				
	    			  str=lst.get(i).getText().trim();
	    			  
	    			  System.out.println(str);
                
	    		if(str.equalsIgnoreCase(WorkOrder.trim())) {
    	  		    List<WebElement> lst1=driver.findElements(By.xpath("//a[contains(text(),'"+str+"')]"));
                        int cnt=lst1.size();
                        if(cnt==1) {
  		    			  //lst.get(i-4).click();
                        	driver.findElement(By.xpath("//div[contains(@class,'wlRSI')]")).click();
  		    			  System.out.println("clicked");
  		    			gm_WriteToLog("Value: "+strvalue+ "for field type: "+WorkOrder+" Found Succesfully from Application","I");
	    				  String TS=fn_GetTimeStamp();
						  imageNameCounter++;
			            	String TestName=gm_TestCaseName("Test_Case_Name");
			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
			  				
			  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  WorkOrder+" Found in application",  str+" Found in application", "Passed", SnapshotPath, 3);
			  				xl_WriteResult(ArrSteps);
							  Reporter.log("Value: "+strvalue+ "found Succesfully from Application");
				    		test.log(LogStatus.PASS, "Value: "+strvalue+ " for field type: "+WorkOrder+" Found Succesfully from Application");

						  break;
						  
                        }
                        if(cnt>1) {
	    			  strvalue=lst.get(i-1).getText().trim();
	    				System.out.println(strvalue);
	    			  if(strvalue.trim().isEmpty()) {
		    				System.out.println("Empty Found");

		    			  lst.get(i-4).click();
		    			  System.out.println("clicked");
		    			  gm_WriteToLog("Value: "+strvalue+ "for field type: "+WorkOrder+" Found Succesfully from Application","I");
	    				  String TS=fn_GetTimeStamp();
						  imageNameCounter++;
			            	String TestName=gm_TestCaseName("Test_Case_Name");
			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
			  				
			  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  WorkOrder+" Found in application",  str+" Found in application", "Passed", SnapshotPath, 3);
			  				xl_WriteResult(ArrSteps);
							  Reporter.log("Value: "+strvalue+ "found Succesfully from Application");
				    		test.log(LogStatus.PASS, "Value: "+strvalue+ " for field type: "+WorkOrder+" Found Succesfully from Application");
				    		break;
						  
	    			  }
	    			  
	    			  
	    			  }
	    			  else {
	    				  
				    test.log(LogStatus.FAIL, "Value: "+strvalue+ " for field type: "+WorkOrder+" Not  Found Succesfully from Application");

	    			  }
				   	}
	    		 else{
		 	           	counter++;
	 	                if(counter==Count) {
	 	                	 imageNameCounter++;
	 		            	gm_WriteToLog("Value: "+strvalue+ "not found Succesfully from Application","E");
	 		            	String TS=fn_GetTimeStamp();
	 		            	String TestName=gm_TestCaseName("Test_Case_Name");
	 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	 		  				
	 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, WorkOrder+"Not Found in application", str+"Not Found in application", "Passed", SnapshotPath, 3);
	 		  				xl_WriteResult(ArrSteps);
	 		  				Reporter.log("Validation Failed. Where Expected- ,"+ WorkOrder+"Not Found in application"+ "Actual-"+ str+"Not Found in application");
	 		    		test.log(LogStatus.FAIL, "Value: "+strvalue+ " not found Succesfully from Application");
	 		  				Assert.assertEquals( WorkOrder+"Not Found in application",  str+"Not Found in application", TestName+" being Validated");
	 			 
				   
			}
	    		 }
			}
				}	

		public void InputOnWebElement(String PropName,String Value) throws InvalidFormatException, IOException, InterruptedException {
		    String Value1=TestDataHM.get(Value);
			gm_Input(PropName,Value1);
		    Thread.sleep(2000);
		
				}	
		
		 
		 
		 public void VerifyNonExistenceData(String text) throws InvalidFormatException, IOException, InterruptedException {
			    String Expected=TestDataHM.get("Expected");
			    String str="";
			    int counter=0;
			   	List<WebElement> lst=driver.findElements(By.xpath("//"+ text));
				int Count=lst.size();
				System.out.println(Count);
				String value=String.valueOf(Count);
				for(WebElement we:lst) {
		    			  str=we.getText().trim();
		    			  System.out.println(str);
		    		if(str.equalsIgnoreCase(Expected)) {
		    			  gm_WriteToLog("Values not verified Succesfully from Application","E");
	    				  String TS=fn_GetTimeStamp();
						  imageNameCounter++;
			            	String TestName=gm_TestCaseName("Test_Case_Name");
			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
			  				
			  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  Expected+"Not Found in application",  Expected+" Found in application", "Failed", SnapshotPath, 3);
			  				xl_WriteResult(ArrSteps);
							  Reporter.log("Value Matching Failed. Where Expecting values Not Found In Application");
				    		test.log(LogStatus.FAIL, "Values not verified Succesfully from Application");

							  Assert.fail("Values not verified Succesfully from Application");	 
					   	}
		    		 else{
			 	           	counter++;
		 	                if(counter==Count) {
		 	                	 imageNameCounter++;
		 		            	gm_WriteToLog("Values verified Succesfully from Application","I");
		 		            	String TS=fn_GetTimeStamp();
		 		            	String TestName=gm_TestCaseName("Test_Case_Name");
		 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		 		  				
		 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected+"Not Found in application", Expected+"Not Found in application", "Passed", SnapshotPath, 3);
		 		  				xl_WriteResult(ArrSteps);
		 		  				Reporter.log("Validation Passed. Where Expected- ,"+ Expected+"Not Found in application"+ "Actual-"+ Expected+"Not Found in application");
		 		    		test.log(LogStatus.PASS, "Values verified Succesfully from Application");
		 		  				Assert.assertEquals( Expected+"Not Found in application",  Expected+"Not Found in application", TestName+" being Validated");
		 			 
					   
				}
		    		 }
				}
}
		
		 public ArrayList<String> AddElementsInList() {
			    String Expected=TestDataHM.get("Expected");
		        ArrayList < String > al=new ArrayList < String >();
		        String[] array=Expected.split(";");
			    for(int i=0;i<=array.length-1;i++) {
				    int counter=0;
			    	String elem=array[i].trim();
			    	al.add(elem);
			    }
			 
			    return al;

		 }
		 
		 public   boolean checkSorting(){
			 ArrayList < String > arraylist=AddElementsInList();
			        boolean isSorted=true;
			        for(int i=1;i < arraylist.size();i++){
			            if(arraylist.get(i-1).compareTo(arraylist.get(i)) > 0){
			                isSorted= false;
		 		    		test.log(LogStatus.FAIL, "Clients are not in Alphabetical sorted Order");
			                break;
			            }
			        }
			        System.out.println(isSorted);
 		    		test.log(LogStatus.PASS, "Clients are in Alphabetical sorted Order");
			        return isSorted;
			        
		 }
		 public void VerifyNonExistenceDataWithAttribute(String text,String Attribute) throws InvalidFormatException, IOException, InterruptedException {
			    String Expected=TestDataHM.get("Expected");
			    String str="";
			    int counter=0;
			   	List<WebElement> lst=driver.findElements(By.xpath("//"+ text));
				int Count=lst.size();
				System.out.println(Count);
				String value=String.valueOf(Count);
				for(WebElement we:lst) {
		    			  str=we.getAttribute(Attribute).trim();
		    		if(str.contains(Expected)) {
		    			  gm_WriteToLog("Values not verified Succesfully from Application","E");
	    				  String TS=fn_GetTimeStamp();
						  imageNameCounter++;
			            	String TestName=gm_TestCaseName("Test_Case_Name");
			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
			  				
			  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  Expected+"Not Found in application",  Expected+" Found in application", "Failed", SnapshotPath, 3);
			  				xl_WriteResult(ArrSteps);
							  Reporter.log("Value Matching Failed. Where Expecting values Not Found In Application");
				    		test.log(LogStatus.FAIL, "Values not verified Succesfully from Application");

							  Assert.fail("Values not verified Succesfully from Application");	 
					   	}
		    		 else{
			 	           	counter++;
		 	                if(counter==Count) {
		 	                	 imageNameCounter++;
		 		            	gm_WriteToLog("Values verified Succesfully from Application","I");
		 		            	String TS=fn_GetTimeStamp();
		 		            	String TestName=gm_TestCaseName("Test_Case_Name");
		 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		 		  				
		 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected+"Not Found in application", Expected+"Not Found in application", "Passed", SnapshotPath, 3);
		 		  				xl_WriteResult(ArrSteps);
		 		  				Reporter.log("Validation Passed. Where Expected- ,"+ Expected+"Not Found in application"+ "Actual-"+ Expected+"Not Found in application");
		 		    		test.log(LogStatus.PASS, "Values verified Succesfully from Application");
		 		  				Assert.assertEquals( Expected+"Not Found in application",  Expected+"Not Found in application", TestName+" being Validated");
		 			 
					   
				}
		    		 }
				}
}
		 public void VerifyNonExistenceDataWithExpected(String text,String Expected) throws InvalidFormatException, IOException, InterruptedException {
			    String PropValue=prop.getProperty(text);
			    String str="";
			    int counter=0;
			   	List<WebElement> lst=driver.findElements(By.xpath(PropValue ));
				int Count=lst.size();
				System.out.println(Count);
				String value=String.valueOf(Count);
				for(WebElement we:lst) {
		    			  str=we.getText().trim();
		    		if(str.contains(Expected)) {
		    			  gm_WriteToLog("Values not verified Succesfully from Application","E");
	    				  String TS=fn_GetTimeStamp();
						  imageNameCounter++;
			            	String TestName=gm_TestCaseName("Test_Case_Name");
			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
			  				
			  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  Expected+"Not Found in application",  Expected+" Found in application", "Failed", SnapshotPath, 3);
			  				xl_WriteResult(ArrSteps);
							  Reporter.log("Value Matching Failed. Where Expecting values Not Found In Application");
				    		test.log(LogStatus.FAIL, "Values not verified Succesfully from Application");

							  Assert.fail("Values not verified Succesfully from Application");	 
					   	}
		    		 else{
			 	           	counter++;
		 	                if(counter==Count) {
		 	                	 imageNameCounter++;
		 		            	gm_WriteToLog("Values verified Succesfully from Application","I");
		 		            	String TS=fn_GetTimeStamp();
		 		            	String TestName=gm_TestCaseName("Test_Case_Name");
		 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		 		  				
		 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected+"Not Found in application", Expected+"Not Found in application", "Passed", SnapshotPath, 3);
		 		  				xl_WriteResult(ArrSteps);
		 		  				Reporter.log("Validation Passed. Where Expected- ,"+ Expected+"Not Found in application"+ "Actual-"+ Expected+"Not Found in application");
		 		    		test.log(LogStatus.PASS, "Values verified Succesfully from Application");
		 		  				Assert.assertEquals( Expected+"Not Found in application",  Expected+"Not Found in application", TestName+" being Validated");
		 			 
					   
				}
		    		 }
				}
}
		
		 
		 public static void DGWOExistence() throws InterruptedException, InvalidFormatException, IOException {
			 driver.navigate().refresh();
			 Thread.sleep(5000);
			  WaitForWebElement("mpticketidtext");
			  String MPWorkOrder=GetElementWithFieldType("span","Ticket Id :")	;
			  while(!MPWorkOrder.contains("DG00")) {
				  Thread.sleep(60000);
					 driver.navigate().refresh();
					  Thread.sleep(10000);
					  WaitForWebElement("mpticketidtext");
					 MPWorkOrder=GetElementWithFieldType("span","Ticket Id :")	;
			  }

		 }
		 public void VerifyNonExistenceDataWithExpectedPropName(String text,String Expected) throws InvalidFormatException, IOException, InterruptedException {
			    String str="";
			    int counter=0;
			   	List<WebElement> lst=driver.findElements(By.xpath("//"+text ));
				int Count=lst.size();
				System.out.println(Count);
				String value=String.valueOf(Count);
				for(WebElement we:lst) {
		    			  str=we.getText().trim();
		    		if(str.contains(Expected)) {
		    			  gm_WriteToLog("Values not verified Succesfully from Application","E");
	    				  String TS=fn_GetTimeStamp();
						  imageNameCounter++;
			            	String TestName=gm_TestCaseName("Test_Case_Name");
			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
			  				
			  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  Expected+"Not Found in application",  Expected+" Found in application", "Failed", SnapshotPath, 3);
			  				xl_WriteResult(ArrSteps);
							  Reporter.log("Value Matching Failed. Where Expecting values Not Found In Application");
				    		test.log(LogStatus.FAIL, "Values not verified Succesfully from Application");

							  Assert.fail("Values not verified Succesfully from Application");	 
					   	}
		    		 else{
			 	           	counter++;
		 	                if(counter==Count) {
		 	                	 imageNameCounter++;
		 		            	gm_WriteToLog("Values verified Succesfully from Application","I");
		 		            	String TS=fn_GetTimeStamp();
		 		            	String TestName=gm_TestCaseName("Test_Case_Name");
		 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		 		  				
		 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected+"Not Found in application", Expected+"Not Found in application", "Passed", SnapshotPath, 3);
		 		  				xl_WriteResult(ArrSteps);
		 		  				Reporter.log("Validation Passed. Where Expected- ,"+ Expected+"Not Found in application"+ "Actual-"+ Expected+"Not Found in application");
		 		    		test.log(LogStatus.PASS, "Value: "+Expected+" not exists in Application");
		 		  				Assert.assertEquals( Expected+"Not Found in application",  Expected+"Not Found in application", TestName+" being Validated");
		 			 
					   
				}
		    		 }
				}
}

		 
		 public void VerifyNonExistenceDataWithPropValue(String PropName) throws InvalidFormatException, IOException, InterruptedException {
			    String propvalue=getpropvalue(PropName);
	  			propvalue=propvalue.split(";")[1].toString().trim();
			    String Expected=TestDataHM.get("Expected");
			    String str="";
			    int counter=0;
			   	List<WebElement> lst=driver.findElements(By.xpath(propvalue));
				int Count=lst.size();
				System.out.println(Count);
				String value=String.valueOf(Count);
				for(WebElement we:lst) {
		    			  str=we.getText().trim();
		    		if(str.contains(Expected)) {
		    			  gm_WriteToLog("Values not verified Succesfully from Application","E");
	    				  String TS=fn_GetTimeStamp();
						  imageNameCounter++;
			            	String TestName=gm_TestCaseName("Test_Case_Name");
			    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
			  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
			  				
			  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  Expected+"Not Found in application",  Expected+" Found in application", "Failed", SnapshotPath, 3);
			  				xl_WriteResult(ArrSteps);
							  Reporter.log("Value Matching Failed. Where Expecting values Not Found In Application");
				    		test.log(LogStatus.FAIL, "Values not verified Succesfully from Application");

							  Assert.fail("Values not verified Succesfully from Application");	 
					   	}
		    		 else{
			 	           	counter++;
		 	                if(counter==Count) {
		 	                	 imageNameCounter++;
		 		            	gm_WriteToLog("Values verified Succesfully from Application","I");
		 		            	String TS=fn_GetTimeStamp();
		 		            	String TestName=gm_TestCaseName("Test_Case_Name");
		 		    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
		 		  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
		 		  				
		 		  			String[] ArrSteps=gm_GetResultStepArray(TestName, Expected+"Not Found in application", Expected+"Not Found in application", "Passed", SnapshotPath, 3);
		 		  				xl_WriteResult(ArrSteps);
		 		  				Reporter.log("Validation Passed. Where Expected- ,"+ Expected+"Not Found in application"+ "Actual-"+ Expected+"Not Found in application");
		 		    		test.log(LogStatus.PASS, "Values verified Succesfully from Application");
		 		  				Assert.assertEquals( Expected+"Not Found in application",  Expected+"Not Found in application", TestName+" being Validated");
		 			 
					   
				}
		    		 }
				}
}
		 
		public static void CheckFileExistence() throws InvalidFormatException, IOException, InterruptedException {
		    Thread.sleep(5000);
			String filename=TestDataHM.get("FileName");

			File f = new File(DownloadedFolder+filename);

			if(f.exists()){
				 gm_WriteToLog("File: "+filename+ " Exists in System","I");
				  String TS=fn_GetTimeStamp();
				  imageNameCounter++;
	            	String TestName=gm_TestCaseName("Test_Case_Name");
	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  				
	  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  "File: "+filename+ " Exists in System",  "File: "+filename+ " Exists in System", "Passed", SnapshotPath, 3);
	  				xl_WriteResult(ArrSteps);
					  Reporter.log("File: "+filename+ " Exists in System");
		    		test.log(LogStatus.PASS, "File: "+filename+ " Exists in System");

			}else{
				gm_WriteToLog("File: "+filename+ " Not Exists in System","E");
				  String TS=fn_GetTimeStamp();
				  imageNameCounter++;
	            	String TestName=gm_TestCaseName("Test_Case_Name");
	    			String SnapshotPath="Results/Snapshots/"+TestName+ "/" +imageNameCounter  + "_";
	  				SnapshotPath=fn_TakeSnapshot(driver, SnapshotPath);
	  				
	  			  String[] ArrSteps=gm_GetResultStepArray(TestName,  "File: "+filename+ " Exists in System",  "File: "+filename+ " Not Exists in System", "Passed", SnapshotPath, 3);
	  				xl_WriteResult(ArrSteps);
					  Reporter.log("File: "+filename+ " Not Exists in System");
		    		test.log(LogStatus.FAIL, "File: "+filename+ " Not Exists in System");

			}
		}
		
	}
	
