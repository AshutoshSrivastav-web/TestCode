package Amazon.Automation.TestCases;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Amazon.Automation.Library.GenericFunctions;
import Amazon.Automation.Pages.Login_Page;


public class TestCases extends Amazon.Automation.Library.GenericFunctions {

	    @AfterClass
		public  void CloseConnection() throws IOException, InterruptedException, InvalidFormatException{
	    	extent.endTest(test);
		 	extent.flush();
		 	driver.quit();
		   }
		@AfterMethod()
		public void afterMethod(ITestResult result) throws InterruptedException {
			getresult(result);	
		}
		
		@BeforeMethod
		public void beforeMethod(Method result) throws InterruptedException {
			test = extent.startTest(result.getName());
			test.log(LogStatus.PASS, result.getName() + " Test Started");
			 
		}
		
		
		 @Test(priority=1)
		 @Parameters({"BrowserType","URL"})
		 public  void TC_VerifyWebsiteOpenedSuccessfully(String BrowserType,String URL) throws IOException, InterruptedException, InvalidFormatException, AWTException{
			 xl_GetData(1);	
			 String Expected=TestDataHM.get("Expected");
			 Login_Page lpg=Amazon.Automation.Library.GenericFunctions.OpenURL(BrowserType,URL);
			 VerifyExpectedtextContainsPassedValuesFromPropName("span", Expected); 
	      	}


	 @Test(priority=2)
	 @Parameters({"BrowserType","URL"})
	 public  void TC_VerifySuccessfulSearch(String BrowserType,String URL) throws IOException, InterruptedException, InvalidFormatException, AWTException{
		 xl_GetData(2);	
		 String Expected=TestDataHM.get("Expected");
		 String SearchName=TestDataHM.get("SearchName");
		 WaitForWebElement("searchbox");
	      VerifyExpectedtextandclick("span","Don't Change");
		 gm_Input("searchbox",SearchName);
	     ClickOnWebElement("searchbutton");
	     VerifyExpectedtextContainsPassedValuesFromPropName("span", Expected);
		   	      	}

	 @Test(priority=3)
	 @Parameters({"BrowserType","URL"})
	 public  void TC_VerifyBookSelected(String BrowserType,String URL) throws IOException, InterruptedException, InvalidFormatException, AWTException{
		 xl_GetData(3);	
		 String SearchName=TestDataHM.get("SearchName");
		 String PropValue=prop.getProperty("selectfilterlist");
		 /* WebElement  we=CreateWebElement(PropValue);
		  Select  sl1=new Select(we);
		  sl1.selectByVisibleText("Price: Low to High");
		  test.log(LogStatus.PASS, "Price: Low to High Selected Successfully");
		  Thread.sleep(8000);
	      VerifyExpectedtextandclick("span","Price: Low to High");*/
		  ClickOnWebElement("nextbutton");
		  List<WebElement> lst=driver.findElements(By.className("s-image"));
		  for(WebElement w:lst) {
			  if(w.getAttribute("class").equalsIgnoreCase("s-image")) {
				  String s=w.getAttribute("alt");
				  w.click();
				  test.log(LogStatus.PASS, "Book: "+s+"Selected");
                  break;
			  }
		  }
		  

		   	      	}

	 @Test(priority=4,enabled=false)
	 @Parameters({"BrowserType","URL"})
	 public  void TC_VerifyCheckOut(String BrowserType,String URL) throws IOException, InterruptedException, InvalidFormatException, AWTException{
		 xl_GetData(4);	
		 String SearchName=TestDataHM.get("SearchName");
		 String PropValue=prop.getProperty("selectfilterlist");
		 String TestName=gm_TestCaseName("Test_Case_Name");
		 String Password=TestDataHM.get("Password");
		 String Expected=TestDataHM.get("Expected");
 		 ClickOnWebElement("buynowbutton");
		  String UserName=TestDataHM.get("UserName");
			 gm_WaitVIsibility("username", 8000);
			 gm_Input("username", UserName);
			 ClickOnWebElement("continue");
			 gm_Input("password", Password);
	         gm_Click("loginbutton");

	}
 		
		
}